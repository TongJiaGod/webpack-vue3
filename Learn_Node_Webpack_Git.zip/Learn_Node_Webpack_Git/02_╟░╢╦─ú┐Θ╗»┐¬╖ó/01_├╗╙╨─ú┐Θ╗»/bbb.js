(function() {
  let name = "bbb"
  console.log(name)
}())


function foo() {
  let name = "foo"
}

function bar() {
  let name = "bar"
}
