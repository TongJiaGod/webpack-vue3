const foo = require("./foo.js")

console.log(foo.name)
console.log(foo.age)
foo.sayHello()

