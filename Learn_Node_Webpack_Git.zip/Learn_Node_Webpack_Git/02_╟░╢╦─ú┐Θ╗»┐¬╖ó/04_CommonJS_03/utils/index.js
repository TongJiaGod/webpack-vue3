function formatDate() {
  return "2022-10-10"
}

module.exports = {
  formatDate
}

