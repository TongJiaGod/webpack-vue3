const name = "foo"
const age = 18
function sayHello() {
  console.log("sayHello")
}

module.exports = {
  name,
  age,
  sayHello
}
