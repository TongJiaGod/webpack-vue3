# day02 作业布置

## 一. 完成课堂所有的代码练习（必须全部自己实现）







## 二. 寻找h元素和p元素的案例，并且实现







## 三. 寻找a元素结合img元素的案例（3个）







## 四. 说出div元素和span元素的作用和区别







## 五. HTML全局属性有哪些？分别是什么作用。





## 六.预习CSS（按照MDN文档）

https://developer.mozilla.org/zh-CN/docs/Learn/CSS/First_steps

