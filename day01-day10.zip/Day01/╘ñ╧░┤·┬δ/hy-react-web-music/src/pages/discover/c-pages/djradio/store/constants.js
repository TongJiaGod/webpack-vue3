export const CHANGE_RADIO_CATEGORY = "djradio/CHANGE_RADIO_CATEGORY";
export const CHANGE_CURRENT_ID = "djradio/CHANGE_CURRENT_ID";
export const CHANGE_RECOMMENDS = "djradio/CHANGE_RECOMMENDS";
export const CHANGE_RADIOS = "djradio/CHANGE_RADIOS";
